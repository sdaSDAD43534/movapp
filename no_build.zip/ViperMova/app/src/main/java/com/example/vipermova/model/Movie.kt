package com.example.vipermova.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// Importar CastMember e Recommendation
import com.example.vipermova.model.CastMember
import com.example.vipermova.model.Recommendation

@Serializable
data class Movie(
    // Mudar tipo de ID de Long para String, pois parece ser um UUID
    val id: String,
    
    // Assumindo que a coluna no Supabase é 'title' (text)
    val title: String? = null, // Use nullavel se puder ser nulo no DB
    
    // Assumindo que a coluna no Supabase é 'backdrop_path' (text)
    // e contém a URL completa da imagem
    @SerialName("backdrop_path") // Mapeia para o nome da coluna se for diferente
    val backdrop_path: String? = null,
    
    // Adicionar campo para a URL da capa
    @SerialName("cover_url")
    val coverUrl: String? = null,
    
    // Adicione outras colunas que você possa precisar
    val overview: String? = null, // Sinopse
    val vote_average: Float? = null, // Avaliação
    val imdb_id: String? = null, // ID do IMDB
    val duration: Int? = null, // Duração em minutos, por exemplo
    val release_year: Int? = null, // Ano de lançamento
    // Para JSON, precisamos da anotação e o tipo correto (List<String>)
    val genres: List<String>? = null, 
    // Para JSON de objetos, precisamos da anotação e da data class correspondente
    val movie_cast: List<CastMember>? = null, 
    // Alterar o tipo para List<Recommendation>
    val recommendations: List<Recommendation>? = null 
) 