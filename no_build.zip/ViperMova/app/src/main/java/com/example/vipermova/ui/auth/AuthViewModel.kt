package com.example.vipermova.ui.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.vipermova.supabase
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.gotrue.SessionStatus
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// Enum para representar o estado de autenticação
enum class AuthStatus {
    LOADING, LOGGED_IN, LOGGED_OUT
}

class AuthViewModel : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _authState = MutableStateFlow(AuthStatus.LOADING)
    val authState: StateFlow<AuthStatus> = _authState.asStateFlow()

    // Evento para sucesso no cadastro (pode ser usado para mostrar mensagem ou navegar)
    private val _registrationSuccess = MutableSharedFlow<Unit>(replay = 0)
    val registrationSuccess: SharedFlow<Unit> = _registrationSuccess.asSharedFlow()

    init {
        observeSessionStatus()
    }

    private fun observeSessionStatus() {
        viewModelScope.launch {
            supabase.auth.sessionStatus.collect { status ->
                _authState.value = when (status) {
                    is SessionStatus.Authenticated -> AuthStatus.LOGGED_IN
                    is SessionStatus.NotAuthenticated -> AuthStatus.LOGGED_OUT
                    is SessionStatus.LoadingFromStorage -> AuthStatus.LOADING
                    // SessionStatus.NetworkError pode ser tratado separadamente se necessário
                    // mostrando uma mensagem específica, por exemplo.
                    // Aqui, estamos tratando como LOGGED_OUT por simplicidade.
                    is SessionStatus.NetworkError -> AuthStatus.LOGGED_OUT 
                }
                // Limpa o erro se o status mudar (exceto erro de rede talvez)
                if (status !is SessionStatus.NetworkError) {
                     _errorMessage.value = null
                }
                 _isLoading.value = status is SessionStatus.LoadingFromStorage
            }
        }
    }

    fun login(emailInput: String, passwordInput: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                supabase.auth.signInWith(Email) {
                    email = emailInput
                    password = passwordInput
                }
                // O observeSessionStatus cuidará de mudar o authState para LOGGED_IN
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Erro desconhecido no login"
                _authState.value = AuthStatus.LOGGED_OUT // Garante que não fique em LOADING
            } finally {
                _isLoading.value = false // Garante que o loading termine mesmo se observeSessionStatus demorar
            }
        }
    }

    fun register(emailInput: String, passwordInput: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                supabase.auth.signUpWith(Email) {
                    email = emailInput
                    password = passwordInput
                }
                // Emite um evento de sucesso no cadastro. A UI pode mostrar uma mensagem
                // ou navegar para o login. O usuário precisará confirmar o email (config padrão do Supabase)
                _registrationSuccess.emit(Unit)
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Erro desconhecido no cadastro"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                supabase.auth.signOut()
                // O observeSessionStatus cuidará de mudar o authState para LOGGED_OUT
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Erro ao fazer logout"
                 _authState.value = AuthStatus.LOGGED_IN // Mantém logado se der erro no signOut
            } finally {
                 _isLoading.value = false
            }
        }
    }

    // Função para limpar a mensagem de erro manualmente, se necessário pela UI
    fun clearError() {
        _errorMessage.value = null
    }
} 