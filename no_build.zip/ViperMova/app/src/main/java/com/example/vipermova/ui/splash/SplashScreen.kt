package com.example.vipermova.ui.splash

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import com.example.vipermova.ui.theme.ViperMovaTheme

@Composable
fun SplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        // Alterado para exibir "VF" com estilo ajustado
        Text(
            text = "VF", // Novas iniciais
            color = MaterialTheme.colorScheme.primary,
            fontSize = 72.sp, // Tamanho ligeiramente ajustado
            fontWeight = FontWeight.SemiBold // Peso um pouco menos intenso
        )
    }
}

@Preview
@Composable
fun SplashScreenPreviewDark() {
    ViperMovaTheme(darkTheme = true) {
        SplashScreen()
    }
}

@Preview
@Composable
fun SplashScreenPreviewLight() {
    ViperMovaTheme(darkTheme = false) {
        SplashScreen()
    }
} 