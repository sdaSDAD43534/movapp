package com.example.vipermova.model

import kotlinx.serialization.Serializable

@Serializable
data class CastMember(
    val name: String? = null,
    val character: String? = null,
    val profile_path: String? = null // Caminho da imagem do perfil
) 