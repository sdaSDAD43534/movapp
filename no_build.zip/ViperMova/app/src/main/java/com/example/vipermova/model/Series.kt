package com.example.vipermova.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Series(
    // Assumindo id como String (UUID) igual a movies
    val id: String,
    
    // Assumindo title como text nullable
    val title: String? = null,
    
    // Mapeando cover_url
    @SerialName("cover_url")
    val coverUrl: String? = null,
    
    val overview: String? = null,
    val backdrop_path: String? = null,
    val genres: List<String>? = null,
    val release_year: Int? = null,
    val end_year: Int? = null,
    val vote_average: Double? = null,
    val status: String? = null,
    val imdb_id: String? = null,
    val total_seasons: Int? = null,
    val total_episodes: Int? = null,
    val is_ongoing: Boolean? = null
) 