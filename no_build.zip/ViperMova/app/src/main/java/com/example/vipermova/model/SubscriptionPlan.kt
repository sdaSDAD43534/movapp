package com.example.vipermova.model

import androidx.compose.ui.graphics.vector.ImageVector

data class SubscriptionPlan(
    val id: String, // Ex: "monthly", "quarterly", "semi_annually"
    val title: String, // Ex: "Mensal"
    val price: Double,
    val period: String, // Ex: "/ mês", "/ 3 meses", "/ 6 meses"
    val benefits: List<String>,
    val icon: ImageVector? = null // Ícone opcional para o plano
) 