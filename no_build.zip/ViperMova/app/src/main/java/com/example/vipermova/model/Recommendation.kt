package com.example.vipermova.model

import kotlinx.serialization.Serializable

@Serializable
data class Recommendation(
    val id: Int,
    val title: String? = null
    // Adicione outros campos se existirem no objeto de recomendação
) 