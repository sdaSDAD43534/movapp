package com.example.vipermova

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.example.vipermova.model.Movie
import com.example.vipermova.model.Series
import com.example.vipermova.ui.theme.ViperMovaTheme
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.foundation.BorderStroke
import androidx.core.view.WindowCompat
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import com.example.vipermova.ui.profile.ProfileScreen
import com.example.vipermova.ui.explore.ExploreScreen
import com.example.vipermova.ui.details.MovieDetailsScreen
import androidx.compose.foundation.clickable
import com.example.vipermova.ui.details.SeriesDetailsScreen
import com.example.vipermova.ui.subscription.SubscriptionScreen
import com.example.vipermova.ui.checkout.CheckoutScreen
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.foundation.lazy.LazyColumn
import androidx.core.graphics.toColorInt
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.unit.IntSize
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache
import coil.util.DebugLogger
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import com.example.vipermova.ui.components.CardDimensions
import com.example.vipermova.ui.components.ImageSize
import com.example.vipermova.ui.components.SimpleMovieSection
import com.example.vipermova.ui.components.SimpleSeriesSection

// Cliente Supabase global
val supabase = createSupabaseClient(
    supabaseUrl = BuildConfig.SUPABASE_URL,
    supabaseKey = BuildConfig.SUPABASE_KEY
) {
    install(Auth)
    install(Postgrest)
}

class MainActivity : ComponentActivity() {
    private val viewModel: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Habilitar Edge-to-Edge ANTES de setContent
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        setContent {
            MovaApp(viewModel = viewModel)
        }
    }
}

@Composable
fun MovaApp(viewModel: HomeViewModel) {
    val navController = rememberNavController()
    val systemInDarkTheme = isSystemInDarkTheme()
    var isDarkMode by remember { mutableStateOf(systemInDarkTheme) }
    
    CompositionLocalProvider(LocalNavController provides navController) {
        ViperMovaTheme(darkTheme = isDarkMode) {
            // Obter a rota atual para controle da BottomBar
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentRoute = navBackStackEntry?.destination?.route
            
            Scaffold(
                // Exibir BottomBar condicionalmente
                bottomBar = {
                    // Verificar se a rota atual NÃO é movieDetails, seriesDetails OU subscription
                    if (currentRoute != null &&
                        !currentRoute.startsWith("movieDetails/") &&
                        !currentRoute.startsWith("seriesDetails/") &&
                        !currentRoute.startsWith("checkout/") &&
                        currentRoute != "subscription") {
                        MovaBottomNavigation(navController)
                    }
                },
                containerColor = Color.Transparent
            ) { paddingValues ->
                val bottomPadding = paddingValues.calculateBottomPadding()
                
                NavHost(
                    navController = navController,
                    startDestination = "home",
                    modifier = Modifier 
                ) {
                    composable("home") {
                        HomeScreen(viewModel = viewModel, bottomPadding = bottomPadding)
                    }
                    composable("explore") {
                        ExploreScreen(bottomPadding = bottomPadding)
                    }
                    composable("my_list") {
                        PlaceholderScreen(title = "Minha Lista", isDarkMode = isDarkMode)
                    }
                    composable("live_tv") {
                        PlaceholderScreen(title = "TV ao Vivo", isDarkMode = isDarkMode)
                    }
                    composable("profile") {
                        ProfileScreen(
                            bottomPadding = bottomPadding,
                            isDarkMode = isDarkMode,
                            onDarkModeChange = { isDarkMode = it }
                        )
                    }
                    
                    // Nova rota para detalhes do filme
                    composable(
                        route = "movieDetails/{movieId}",
                        arguments = listOf(navArgument("movieId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val movieId = backStackEntry.arguments?.getString("movieId")
                        MovieDetailsScreen(movieId = movieId, navController = navController)
                    }
                    
                    // Nova rota para detalhes da série
                    composable(
                        route = "seriesDetails/{seriesId}",
                        arguments = listOf(navArgument("seriesId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val seriesId = backStackEntry.arguments?.getString("seriesId")
                        SeriesDetailsScreen(seriesId = seriesId, navController = navController)
                    }
                    
                    // Nova rota para Assinatura
                    composable("subscription") {
                        SubscriptionScreen(navController = navController)
                    }

                    // Nova rota para Checkout
                    composable(
                        route = "checkout/{planId}",
                        arguments = listOf(navArgument("planId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val planId = backStackEntry.arguments?.getString("planId")
                        CheckoutScreen(planId = planId, navController = navController)
                    }
                }
            }
        }
    }
}

@Composable
fun MovaBottomNavigation(navController: NavController) {
    val items = listOf(
        NavigationItem("home", "Home", Icons.Default.Home),
        NavigationItem("explore", "Explorar", Icons.Default.Explore),
        NavigationItem("my_list", "Favoritos", Icons.Default.FavoriteBorder),
        NavigationItem("live_tv", "TV", Icons.Default.LiveTv),
        NavigationItem("profile", "Perfil", Icons.Default.Person)
    )
    
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surfaceContainer,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        items.forEach { item ->
            val selected = currentRoute == item.route
            val iconColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            val textColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            
            NavigationBarItem(
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = iconColor
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        color = textColor,
                        fontSize = 12.sp
                    )
                },
                selected = selected,
                onClick = {
                    if (currentRoute != item.route) {
                        navController.navigate(item.route) {
                            popUpTo(navController.graph.startDestinationId)
                            launchSingleTop = true
                        }
                    }
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = MaterialTheme.colorScheme.secondaryContainer
                )
            )
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    bottomPadding: Dp = 0.dp,
    modifier: Modifier = Modifier
) {
    val movies by viewModel.movies.collectAsState()
    val series by viewModel.series.collectAsState()
    val isLoadingMovies by viewModel.isLoadingMovies.collectAsState()
    val isLoadingSeries by viewModel.isLoadingSeries.collectAsState()
    val moviesError by viewModel.moviesError.collectAsState()
    val seriesError by viewModel.seriesError.collectAsState()
    val scrollState = rememberScrollState()
    val currentNavController = LocalNavController.current
    
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(bottom = bottomPadding)
    ) {
        // Banner principal
        FeaturedMovie(
            movies = movies,
            isLoading = isLoadingMovies,
            error = moviesError
        )
        
        // Seção de filmes simplificada
        if (!isLoadingMovies && moviesError == null && movies.isNotEmpty()) {
            SimpleMovieSection(
            title = "Lançamentos",
            movies = movies,
                navController = currentNavController!!
        )
        }
        
        // Seção de séries simplificada
        if (!isLoadingSeries && seriesError == null && series.isNotEmpty()) {
            SimpleSeriesSection(
            title = "Séries",
            seriesList = series,
                navController = currentNavController!!
        )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FeaturedMovie(
    movies: List<Movie>,
    isLoading: Boolean,
    error: String?
) {
    val pagerState = rememberPagerState(
        initialPage = Int.MAX_VALUE / 2,
        pageCount = { Int.MAX_VALUE }
    )
    val coroutineScope = rememberCoroutineScope()

    // Efeito para mudança automática de páginas com animação suave
    LaunchedEffect(movies) {
        while (true) {
            delay(4000) // Espera 4 segundos
            if (movies.isNotEmpty()) {
                pagerState.animateScrollToPage(
                    page = pagerState.currentPage + 1,
                    animationSpec = spring(
                        dampingRatio = Spring.DampingRatioNoBouncy,
                        stiffness = Spring.StiffnessVeryLow
                    )
                )
            }
        }
    }
    
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center)
            )
        } else if (error != null) {
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.align(Alignment.Center)
            )
        } else if (movies.isNotEmpty()) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val movie = movies[page % movies.size]
                    Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = movie.backdrop_path,
                    contentDescription = movie.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                        )
                        
                        // Gradiente com comportamento diferente para tema claro e escuro
                        val isDarkTheme = isSystemInDarkTheme()
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = if (isDarkTheme) {
                                            listOf(
                                                Color.Transparent,
                                                Color.Transparent,
                                                Color.Black.copy(alpha = 0.1f),
                                                Color.Black.copy(alpha = 0.2f),
                                                Color.Black.copy(alpha = 0.3f),
                                                Color.Black.copy(alpha = 0.4f),
                                                Color.Black.copy(alpha = 0.5f),
                                                Color.Black.copy(alpha = 0.6f),
                                                Color.Black.copy(alpha = 0.7f),
                                                Color.Black.copy(alpha = 0.8f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.85f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.9f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.95f),
                                                MaterialTheme.colorScheme.background
                                            )
                                        } else {
                                            listOf(
                                                Color.Transparent,
                                                Color.Transparent,
                                                Color.White.copy(alpha = 0.1f),
                                                Color.White.copy(alpha = 0.2f),
                                                Color.White.copy(alpha = 0.3f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.4f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.6f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.7f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.8f),
                                                MaterialTheme.colorScheme.background.copy(alpha = 0.9f),
                                                MaterialTheme.colorScheme.background
                                            )
                                        },
                                        startY = if (isDarkTheme) 50f else 150f
                                    )
                                )
                        )
                        
                        // Container para título e botões
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 16.dp, bottom = 16.dp, end = 16.dp)
                        ) {
                            Text(
                                text = movie.title ?: "",
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                            
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { /* TODO: Implementar ação de play */ },
                                    modifier = Modifier.height(32.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp),
                                    shape = CircleShape
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "Assistir",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                                
                                Button(
                                    onClick = { /* TODO: Implementar ação de favoritar */ },
                                    modifier = Modifier.height(32.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color.Black.copy(alpha = 0.5f)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp),
                                    shape = CircleShape
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.FavoriteBorder,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Text(
                                            text = "Add aos favoritos",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // Indicadores de paginação
        if (!isLoading && error == null && movies.isNotEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, end = 16.dp),
                horizontalArrangement = Arrangement.End
            ) {
                repeat(movies.size) { index ->
                    val isSelected = (pagerState.currentPage % movies.size) == index
                    Box(
                        modifier = Modifier
                            .size(
                                width = if (isSelected) 24.dp else 8.dp,
                                height = 8.dp
                            )
                            .background(
                                color = if (isSelected) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                                },
                                shape = CircleShape
                            )
                    )
                    if (index < movies.size - 1) {
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun LoadingState() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        CircularProgressIndicator()
    }
}

@Composable
fun ErrorState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            color = MaterialTheme.colorScheme.error
        )
    }
}

@Composable
fun EmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = message,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

class HomeViewModel : ViewModel() {
    private val _movies = MutableStateFlow<List<Movie>>(emptyList())
    val movies: StateFlow<List<Movie>> = _movies.asStateFlow()
    
    private val _series = MutableStateFlow<List<Series>>(emptyList())
    val series: StateFlow<List<Series>> = _series.asStateFlow()
    
    private val _isLoadingMovies = MutableStateFlow(false)
    val isLoadingMovies: StateFlow<Boolean> = _isLoadingMovies.asStateFlow()
    
    private val _isLoadingSeries = MutableStateFlow(false)
    val isLoadingSeries: StateFlow<Boolean> = _isLoadingSeries.asStateFlow()
    
    private val _moviesError = MutableStateFlow<String?>(null)
    val moviesError: StateFlow<String?> = _moviesError.asStateFlow()
    
    private val _seriesError = MutableStateFlow<String?>(null)
    val seriesError: StateFlow<String?> = _seriesError.asStateFlow()
    
    private val _moviesPage = MutableStateFlow(0)
    val moviesPage: StateFlow<Int> = _moviesPage.asStateFlow()
    
    private val _seriesPage = MutableStateFlow(0)
    val seriesPage: StateFlow<Int> = _seriesPage.asStateFlow()
    
    init {
        loadInitialData()
    }
    
    private fun loadInitialData() {
        viewModelScope.launch(Dispatchers.IO) {
            loadMovies()
            loadSeries()
        }
    }
    
    private suspend fun loadMovies() {
        try {
            _isLoadingMovies.value = true
            _moviesError.value = null
            
            val initialMovies = supabase
                .from("movies")
                .select()
                .decodeList<Movie>()
                .take(5)
            
            _movies.value = initialMovies
        } catch (e: Exception) {
            _moviesError.value = e.message
        } finally {
            _isLoadingMovies.value = false
        }
    }
    
    private suspend fun loadSeries() {
        try {
            _isLoadingSeries.value = true
            _seriesError.value = null
            
            val initialSeries = supabase
                .from("series")
                .select()
                .decodeList<Series>()
                .take(5)
            
            _series.value = initialSeries
        } catch (e: Exception) {
            _seriesError.value = e.message
        } finally {
            _isLoadingSeries.value = false
        }
    }
    
    fun loadMoreMovies() {
        if (_isLoadingMovies.value) return
        
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _isLoadingMovies.value = true
                val nextPage = _moviesPage.value + 1
                val start = nextPage * 5
                
                val moreMovies = supabase
                    .from("movies")
                    .select()
                    .decodeList<Movie>()
                    .drop(start)
                    .take(5)
                
                if (moreMovies.isNotEmpty()) {
                    _movies.value = _movies.value + moreMovies
                    _moviesPage.value = nextPage
                }
            } catch (e: Exception) {
                _moviesError.value = e.message
            } finally {
                _isLoadingMovies.value = false
            }
        }
    }
    
    fun loadMoreSeries() {
        if (_isLoadingSeries.value) return
        
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _isLoadingSeries.value = true
                val nextPage = _seriesPage.value + 1
                val start = nextPage * 5
                
                val moreSeries = supabase
                    .from("series")
                    .select()
                    .decodeList<Series>()
                    .drop(start)
                    .take(5)
                
                if (moreSeries.isNotEmpty()) {
                    _series.value = _series.value + moreSeries
                    _seriesPage.value = nextPage
                }
            } catch (e: Exception) {
                _seriesError.value = e.message
            } finally {
                _isLoadingSeries.value = false
            }
        }
    }
}

@Composable
fun MovieSection(
    title: String, 
    movies: List<Movie>,
    isLoading: Boolean,
    error: String?
) {
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    
    val dimensions = remember(configuration) {
    val screenWidth = configuration.screenWidthDp.dp
    val screenHeight = configuration.screenHeightDp.dp
        CardDimensions(
            width = screenWidth / 3.5f,
            height = screenHeight / 4.5f
        )
    }
    
    // Log para monitorar o estado da seção
    LaunchedEffect(movies.size, isLoading, error) {
        Log.d("MovieSection", """
            Estado da seção:
            - Título: $title
            - Quantidade de filmes: ${movies.size}
            - Carregando: $isLoading
            - Erro: $error
        """.trimIndent())
    }
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            
            Text(
                text = "Ver todos",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        when {
            isLoading -> LoadingState()
            error != null -> ErrorState(error)
            movies.isEmpty() -> EmptyState("Nenhum filme encontrado.")
            else -> {
                val currentNavController = LocalNavController.current
                val listState = rememberLazyListState()
                
                // Log para monitorar o estado da lista
                LaunchedEffect(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) {
                    Log.d("MovieSection", """
                        Estado da lista:
                        - Primeiro item visível: ${listState.firstVisibleItemIndex}
                        - Offset do scroll: ${listState.firstVisibleItemScrollOffset}
                        - LayoutInfo: ${listState.layoutInfo.visibleItemsInfo.size} itens visíveis
                    """.trimIndent())
                }
                
                LazyRow(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(
                        items = movies,
                        key = { it.id }
                    ) { movie ->
                        // Log para monitorar o carregamento de cada item
                        LaunchedEffect(movie.id) {
                            Log.d("MovieSection", "Carregando filme: ${movie.title} (ID: ${movie.id})")
                        }
                        
                        MovieCard(
                            movie = movie, 
                            navController = currentNavController,
                            dimensions = dimensions
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SeriesSection(
    title: String, 
    seriesList: List<Series>,
    isLoading: Boolean,
    error: String?
) {
    val configuration = LocalConfiguration.current
    val density = LocalDensity.current
    
    val dimensions = remember(configuration) {
    val screenWidth = configuration.screenWidthDp.dp
    val screenHeight = configuration.screenHeightDp.dp
        CardDimensions(
            width = screenWidth / 3.5f,
            height = screenHeight / 4.5f
        )
    }
    
    // Log para monitorar o estado da seção
    LaunchedEffect(seriesList.size, isLoading, error) {
        Log.d("SeriesSection", """
            Estado da seção:
            - Título: $title
            - Quantidade de séries: ${seriesList.size}
            - Carregando: $isLoading
            - Erro: $error
        """.trimIndent())
    }
    
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = MaterialTheme.colorScheme.onBackground,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Ver todos",
                color = MaterialTheme.colorScheme.primary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        
        when {
            isLoading -> LoadingState()
            error != null -> ErrorState(error)
            seriesList.isEmpty() -> EmptyState("Nenhuma série encontrada.")
            else -> {
                val currentNavController = LocalNavController.current
                val listState = rememberLazyListState()
                
                // Log para monitorar o estado da lista
                LaunchedEffect(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) {
                    Log.d("SeriesSection", """
                        Estado da lista:
                        - Primeiro item visível: ${listState.firstVisibleItemIndex}
                        - Offset do scroll: ${listState.firstVisibleItemScrollOffset}
                        - LayoutInfo: ${listState.layoutInfo.visibleItemsInfo.size} itens visíveis
                    """.trimIndent())
                }
                
                LazyRow(
                    state = listState,
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(
                        items = seriesList,
                        key = { it.id }
                    ) { series ->
                        // Log para monitorar o carregamento de cada item
                        LaunchedEffect(series.id) {
                            Log.d("SeriesSection", "Carregando série: ${series.title} (ID: ${series.id})")
                        }
                        
                        SeriesCard(
                            series = series, 
                            navController = currentNavController,
                            dimensions = dimensions
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MovieCard(
    movie: Movie,
    modifier: Modifier = Modifier,
    navController: NavController? = null,
    dimensions: CardDimensions
) {
    val density = LocalDensity.current
    val context = LocalContext.current
    
    // Mover o cálculo do imageSize para fora do Composable usando remember
    val imageSize = remember(dimensions) {
        ImageSize(
            width = with(density) { dimensions.width.roundToPx() },
            height = with(density) { dimensions.height.roundToPx() }
        )
    }
    
    // Criar o ImageRequest fora do Composable
    val imageRequest = remember(movie.id, imageSize) {
        ImageRequest.Builder(context)
            .data(movie.coverUrl)
            .crossfade(true)
            .size(imageSize.width, imageSize.height)
            .build()
    }
    
    Card(
        modifier = modifier
            .width(dimensions.width)
            .height(dimensions.height)
            .clickable(enabled = navController != null) { 
                navController?.navigate("movieDetails/${movie.id}")
            },
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
            AsyncImage(
            model = imageRequest,
            contentDescription = movie.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            placeholder = painterResource(id = R.drawable.placeholder_poster),
            error = painterResource(id = R.drawable.placeholder_poster)
        )
    }
}

@Composable
fun SeriesCard(
    series: Series,
    modifier: Modifier = Modifier,
    navController: NavController? = null,
    dimensions: CardDimensions
) {
    val density = LocalDensity.current
    val context = LocalContext.current
    
    // Mover o cálculo do imageSize para fora do Composable usando remember
    val imageSize = remember(dimensions) {
        ImageSize(
            width = with(density) { dimensions.width.roundToPx() },
            height = with(density) { dimensions.height.roundToPx() }
        )
    }
    
    // Criar o ImageRequest fora do Composable
    val imageRequest = remember(series.id, imageSize) {
        ImageRequest.Builder(context)
                    .data(series.coverUrl)
                    .crossfade(true)
            .size(imageSize.width, imageSize.height)
            .build()
    }
    
    Card(
        modifier = modifier
            .width(dimensions.width)
            .height(dimensions.height)
            .clickable(enabled = navController != null) { 
                navController?.navigate("seriesDetails/${series.id}")
            },
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        AsyncImage(
            model = imageRequest,
                contentDescription = series.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
                placeholder = painterResource(id = R.drawable.placeholder_poster),
                error = painterResource(id = R.drawable.placeholder_poster)
            )
    }
}

data class NavigationItem(
    val route: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@OptIn(ExperimentalFoundationApi::class)
@Preview(showBackground = true, backgroundColor = 0xFF121212)
@Composable
fun FeaturedMoviePreview() {
    ViperMovaTheme(darkTheme = true) {
        val dummyPagerState = rememberPagerState(pageCount = { 1 })
        val dummyMovie = Movie(id = "1", title = "Filme de Exemplo", backdrop_path = "")
        FeaturedMovie(
            movies = listOf(dummyMovie),
            isLoading = false,
            error = null
        )
    }
}

@Preview
@Composable
fun HomeScreenPreview() {
    val viewModel = remember { HomeViewModel() }
    MovaApp(viewModel = viewModel)
}

@Composable
fun PlaceholderScreen(title: String, isDarkMode: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Tela: $title",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 24.sp
        )
    }
}

@Preview
@Composable
fun MovieCardPreview() {
    ViperMovaTheme(darkTheme = true) {
        val dummyMovie = Movie(id = "2", title = "Outro Filme", coverUrl = "")
        val previewDimensions = CardDimensions(width = 140.dp, height = 200.dp)
        MovieCard(
            movie = dummyMovie,
            dimensions = previewDimensions
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFF121212)
@Composable
fun SeriesSectionPreview() {
    ViperMovaTheme(darkTheme = true) {
        val dummySeries = List(5) { Series(id = "s$it", title = "Série ${it+1}", coverUrl = "") }
        SeriesSection(title = "Séries", seriesList = dummySeries, isLoading = false, error = null)
    }
}

@Preview
@Composable
fun SeriesCardPreview() {
    ViperMovaTheme(darkTheme = true) {
        val dummySeries = Series(id = "s1", title = "Série Legal", coverUrl = "")
        val previewDimensions = CardDimensions(width = 140.dp, height = 200.dp)
        SeriesCard(
            series = dummySeries,
            dimensions = previewDimensions
        )
    }
}

// Adicionar um LocalNavController para facilitar o acesso
val LocalNavController = staticCompositionLocalOf<NavController?> { null } 