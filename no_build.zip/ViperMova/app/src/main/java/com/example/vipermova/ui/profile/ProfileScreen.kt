package com.example.vipermova.ui.profile // Pacote para a tela de perfil

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.BorderStroke
import com.example.vipermova.R // Para o logo se for drawable
import com.example.vipermova.ui.theme.ViperMovaTheme
import com.example.vipermova.LocalNavController // Importar LocalNavController

@Composable
fun ProfileScreen(
    bottomPadding: Dp, 
    isDarkMode: Boolean, // Recebe estado
    onDarkModeChange: (Boolean) -> Unit, // Recebe callback
    onLogout: () -> Unit = {} // Adicionar parâmetro onLogout
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(bottom = bottomPadding)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SimpleTopAppBar()

        Spacer(modifier = Modifier.height(24.dp))

        ProfileImagePlaceholder()

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Henrique Viegas",
            color = MaterialTheme.colorScheme.onBackground, 
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(modifier = Modifier.height(32.dp))

        PremiumCard()

        Spacer(modifier = Modifier.height(32.dp))

        ProfileOptionsList(
            isDarkMode = isDarkMode, 
            onDarkModeChange = onDarkModeChange,
            onLogout = onLogout // Passar onLogout
        )
        
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun SimpleTopAppBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "M", 
            color = MaterialTheme.colorScheme.primary,
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = "Perfil",
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 20.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun ProfileImagePlaceholder(/*modifier: Modifier = Modifier*/) {
    Box(
        modifier = Modifier 
            .size(120.dp)
            .clip(CircleShape)
            .background(Color.Gray.copy(alpha = 0.3f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Person,
            contentDescription = "Foto de Perfil",
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            modifier = Modifier.size(60.dp)
        )
    }
}

@Composable
fun PremiumCard() {
    val navController = LocalNavController.current // Obter NavController
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clickable(enabled = navController != null) { // Habilitar clique se navController existir
                navController?.navigate("subscription") 
            },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha=0.3f),
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = "Seja Premium!",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 18.sp
                )
                Text(
                    text = "Aproveite filmes e séries sem limites",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun ProfileOptionsList(
    isDarkMode: Boolean, 
    onDarkModeChange: (Boolean) -> Unit,
    onLogout: () -> Unit // Adicionar parâmetro onLogout
) {
    val itemTextColor = MaterialTheme.colorScheme.onBackground
    val itemIconColor = MaterialTheme.colorScheme.onSurfaceVariant
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        ProfileOptionItem(icon = Icons.Default.PersonOutline, text = "Editar Perfil", textColor = itemTextColor, iconColor = itemIconColor)
        ProfileOptionItem(icon = Icons.Default.History, text = "Histórico de Compras", textColor = itemTextColor, iconColor = itemIconColor)
        ProfileOptionItem(icon = Icons.Default.NotificationsNone, text = "Notificação", textColor = itemTextColor, iconColor = itemIconColor)
        ProfileOptionItem(icon = Icons.AutoMirrored.Filled.HelpOutline, text = "Central de Ajuda", textColor = itemTextColor, iconColor = itemIconColor)
        ProfileOptionItem(icon = Icons.Default.Policy, text = "Política de Privacidade", textColor = itemTextColor, iconColor = itemIconColor)
        ProfileOptionItemSwitch(icon = Icons.Default.DarkMode, text = "Modo Escuro", checked = isDarkMode, onCheckedChange = onDarkModeChange, textColor = itemTextColor, iconColor = itemIconColor)
        ProfileOptionItem(
            icon = Icons.AutoMirrored.Filled.Logout, 
            text = "Sair", 
            isDestructive = true, 
            textColor = Color.Red, 
            iconColor = Color.Red,
            onClick = onLogout // Conectar o botão ao onLogout
        )
    }
}

@Composable
fun ProfileOptionItem(
    icon: ImageVector,
    text: String,
    textColor: Color,
    iconColor: Color,
    onClick: () -> Unit = { /* TODO */ },
    isDestructive: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isDestructive) iconColor else iconColor,
            modifier = Modifier.size(26.dp)
        )
        Spacer(modifier = Modifier.width(20.dp))
        Text(
            text = text,
            color = if (isDestructive) textColor else textColor,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = Color.Gray,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun ProfileOptionItemSwitch(
    icon: ImageVector,
    text: String,
    textColor: Color,
    iconColor: Color,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = iconColor,
            modifier = Modifier.size(26.dp)
        )
        Spacer(modifier = Modifier.width(20.dp))
        Text(
            text = text,
            color = textColor,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = MaterialTheme.colorScheme.primary,
                uncheckedThumbColor = Color.LightGray,
                uncheckedTrackColor = Color.Gray.copy(alpha = 0.5f)
            )
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ProfileScreenPreview() {
    ViperMovaTheme(darkTheme = true) {
        ProfileScreen(
            bottomPadding = 80.dp, 
            isDarkMode = true, 
            onDarkModeChange = {},
            onLogout = {} // Adicionar parâmetro
        ) 
    }
}

@Preview(showBackground = true)
@Composable
fun ProfileScreenLightPreview() {
    ViperMovaTheme(darkTheme = false) {
        ProfileScreen(
            bottomPadding = 80.dp, 
            isDarkMode = false, 
            onDarkModeChange = {},
            onLogout = {} // Adicionar parâmetro
        ) 
    }
} 