package com.example.vipermova.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Pix
import androidx.compose.material.icons.filled.Storefront // Exemplo para Mercado Pago
import androidx.compose.ui.graphics.vector.ImageVector

enum class PaymentMethod(val title: String, val icon: ImageVector) {
    CREDIT_CARD("Cartão de Crédito", Icons.Default.CreditCard),
    PIX("Pix", Icons.Filled.Pix), // Use Filled.Pix se disponível ou importe
    MERCADO_PAGO("Mercado Pago", Icons.Default.Storefront) // Ícone de exemplo
} 