package com.example.vipermova.ui.details

import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.vipermova.BuildConfig
import com.example.vipermova.R
import com.example.vipermova.model.CastMember
import com.example.vipermova.model.Movie
import com.example.vipermova.supabase
import com.example.vipermova.ui.components.LoadingIndicatorViperFlix
import com.example.vipermova.ui.components.VideoPlayer
import com.example.vipermova.ui.components.VipDialog
import com.example.vipermova.ui.theme.ViperMovaTheme
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MovieDetailsScreen(
    movieId: String?,
    navController: NavController
) {
    var movie by remember { mutableStateOf<Movie?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var showPlayer by remember { mutableStateOf(true) }
    var showVipDialog by remember { mutableStateOf(false) }

    // Função para lidar com o botão voltar
    val handleBackClick = {
        if (showPlayer) {
            navController.popBackStack()
        }
    }

    LaunchedEffect(movieId) {
        if (movieId == null) {
            error = "ID do filme inválido"
            isLoading = false
            return@LaunchedEffect
        }
        isLoading = true
        error = null
        try {
            val result = withContext(Dispatchers.IO) {
                supabase.from("movies")
                    .select {
                        filter {
                            eq("id", movieId)
                        }
                        limit(1)
                    }
                    .decodeSingleOrNull<Movie>()
            }
            movie = result
            if (movie == null) {
                error = "Filme não encontrado"
            }
        } catch (e: Exception) {
            Log.e("MovieDetails", "Erro ao buscar detalhes do filme: ${e.message}", e)
            error = "Erro ao carregar detalhes"
        } finally {
            isLoading = false
        }
    }

    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        if (isLoading) {
            LoadingIndicatorViperFlix()
        } else if (error != null) {
            val currentError = error!!
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = currentError, color = MaterialTheme.colorScheme.error)
            }
        } else movie?.let { currentMovie ->
            Box(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Player fixo no topo
                    Box(modifier = Modifier.fillMaxWidth()) {
                        if (showPlayer && currentMovie.imdb_id != null) {
                            VideoPlayer(
                                videoUrl = "https://storage.googleapis.com/movies_vod/${currentMovie.imdb_id}.mp4",
                                backdropUrl = currentMovie.backdrop_path,
                                modifier = Modifier.fillMaxWidth(),
                                onBackClick = handleBackClick
                            )
                        } else {
                            MovieBackdrop(movie = currentMovie, navController = navController)
                        }
                    }

                    // Conteúdo rolável
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                    ) {
                        MoviePrimaryInfo(movie = currentMovie)
                        ActionButtons(
                            onPlayClick = { showPlayer = true }
                        )
                        MovieSynopsis(movie = currentMovie)
                        MovieCastSection(castList = currentMovie.movie_cast ?: emptyList())
                        TabSection()
                        
                        // Adiciona um espaço extra no final para garantir que todo o conteúdo possa ser rolado
                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }
            }
        } ?: run {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "Não foi possível carregar o filme.")
            }
        }
    }
}

// --- Componentes da Tela de Detalhes ---

@Composable
fun MovieBackdrop(movie: Movie, navController: NavController) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp) // Altura ajustável
    ) {
        AsyncImage(
            model = movie.backdrop_path ?: "",
            contentDescription = movie.title ?: "Banner do Filme",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            placeholder = painterResource(id = R.drawable.ic_launcher_background), // Placeholder genérico
            error = painterResource(id = R.drawable.ic_launcher_background)
        )
        // Gradiente para escurecer a parte inferior da imagem
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, MaterialTheme.colorScheme.background),
                        startY = 400f // Ajustar início do gradiente
                    )
                )
        )
        // Botão Voltar
        IconButton(
            onClick = { navController.popBackStack() },
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding() // Adiciona padding para não ficar sob a barra de status
                .padding(8.dp)
                .background(Color.Black.copy(alpha = 0.4f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar",
                tint = Color.White
            )
        }
         // Ícones de ação no topo (Adicionar aos Favoritos, Compartilhar)
        Row(
             modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(8.dp)
        ){
             IconButton(
                onClick = { /* TODO: Ação Favoritar */ },
                modifier = Modifier.background(Color.Black.copy(alpha = 0.4f), CircleShape).padding(end=4.dp)
            ) {
                Icon(
                    // Usar BookmarkBorder ou FavoriteBorder
                    imageVector = Icons.Default.BookmarkBorder,
                    contentDescription = "Adicionar aos Favoritos",
                    tint = Color.White
                )
            }
            IconButton(
                onClick = { /* TODO: Ação Compartilhar */ },
                 modifier = Modifier.background(Color.Black.copy(alpha = 0.4f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Compartilhar",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
fun MoviePrimaryInfo(movie: Movie) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            text = movie.title ?: "Título não disponível",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.Star, contentDescription = "Rating", tint = Color.Yellow, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "%.1f".format(movie.vote_average ?: 0f), // Formata para 1 casa decimal
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("•", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = movie.release_year?.toString() ?: "-",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
             Spacer(modifier = Modifier.width(8.dp))
            Text("•", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.width(8.dp))
            // Exemplo de "Tag" (como CANADA na imagem)
             Text(
                text = "EXEMPLO", // Substituir por dados reais se houver
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                 modifier = Modifier.border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(4.dp)).padding(horizontal = 4.dp, vertical = 2.dp)
            )
           
            // Duração - Pode ser adicionada aqui se desejado
            // Spacer(modifier = Modifier.width(8.dp))
            // Text("•", color = MaterialTheme.colorScheme.onSurfaceVariant)
            // Spacer(modifier = Modifier.width(8.dp))
            // Text(
            //    text = "${movie.duration ?: 0} min", 
            //    style = MaterialTheme.typography.bodyMedium,
            //    color = MaterialTheme.colorScheme.onSurfaceVariant
            // )
        }
        Spacer(modifier = Modifier.height(8.dp))
         // Gêneros
        Text(
            text = "Gênero: ${movie.genres?.joinToString() ?: "Não informado"}", // Junta a lista de gêneros
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

    }
}

@Composable
fun ActionButtons(
    onPlayClick: () -> Unit
) {
    var showVipDialog by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Button(
            onClick = onPlayClick,
            modifier = Modifier
                .weight(1f)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.PlayArrow, "Play", modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Play", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedButton(
            onClick = { showVipDialog = true },
            modifier = Modifier
                .weight(1f)
                .height(50.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.primary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Download, "Download", modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Download", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
    }

    if (showVipDialog) {
        VipDialog(
            onDismiss = { showVipDialog = false },
            onAssinarClick = {
                // TODO: Implementar navegação para tela de assinatura
                showVipDialog = false
            }
        )
    }
}

@Composable
fun MovieSynopsis(movie: Movie) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
         Text(
            text = movie.overview ?: "Sinopse não disponível.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 4, // Limitar linhas iniciais
            overflow = TextOverflow.Ellipsis // Adicionar '...' se o texto for cortado
            // TODO: Adicionar lógica "Ver mais" se necessário
        )
    }
}

@Composable
fun MovieCastSection(castList: List<CastMember>) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(
            text = "Elenco",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        if (castList.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(castList) { castMember ->
                    CastMemberItem(castMember = castMember)
                }
            }
        } else {
             Text(
                text = "Informações do elenco não disponíveis.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

@Composable
fun CastMemberItem(castMember: CastMember) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(80.dp)) {
        AsyncImage(
            model = castMember.profile_path ?: "",
            contentDescription = castMember.name ?: "Foto do Ator",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(70.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant), // Cor de fundo caso imagem falhe
             placeholder = painterResource(id = R.drawable.ic_launcher_background), // Placeholder
             error = painterResource(id = R.drawable.ic_launcher_background) // Imagem de erro (pode ser um placeholder de pessoa)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = castMember.name ?: "",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
         Text(
            text = castMember.character ?: "",
            style = MaterialTheme.typography.labelSmall,
             color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TabSection() {
    var selectedTabIndex by remember { mutableStateOf(0) }
    val tabs = listOf("Trailers", "Semelhantes", "Comentários") 

    Column(modifier = Modifier.padding(top = 16.dp)) {
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = MaterialTheme.colorScheme.surface, 
            contentColor = MaterialTheme.colorScheme.primary,
             // Corrigir o indicador para usar tabPositions
             indicator = { tabPositions ->
                 if (selectedTabIndex < tabPositions.size) { // Adicionar verificação de segurança
                    TabRowDefaults.Indicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = MaterialTheme.colorScheme.primary
                    )
                 }
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = { Text(title, fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal) },
                    selectedContentColor = MaterialTheme.colorScheme.primary,
                    unselectedContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Conteúdo da Aba Selecionada (Placeholder por enquanto)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp) // Altura de exemplo
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            when (selectedTabIndex) {
                0 -> Text("Conteúdo dos Trailers aqui") // TODO: Implementar lista de trailers
                1 -> Text("Conteúdo de Filmes/Séries Semelhantes aqui") // TODO: Implementar lista de recomendações
                2 -> Text("Conteúdo dos Comentários aqui") // TODO: Implementar seção de comentários
            }
        }
    }
}

// --- Preview --- 
@Preview(showBackground = true, name = "Details Dark")
@Composable
fun MovieDetailsScreenPreview() {
    ViperMovaTheme(darkTheme = true) {
        // Criar NavController diretamente para o preview
        val mockNavController = NavController(LocalContext.current)
         // Mock de Filme com alguns dados
        val mockMovie = Movie(
            id = "1", 
            title = "Coringa", 
            backdrop_path = "", 
            vote_average = 8.2f,
            release_year = 2019,
            genres = listOf("Crime", "Drama", "Thriller"),
            overview = "Durante os anos 1980, um comediante de stand-up falido é levado à loucura e se torna uma figura psicopata de crime e caos em Gotham City, tornando-se uma figura infame.",
            movie_cast = listOf(
                CastMember(name = "Joaquin Phoenix", character = "Arthur Fleck", profile_path = ""),
                CastMember(name = "Robert De Niro", character = "Murray Franklin", profile_path = "")
            )
        )
        // Simular estado de carregado
        MovieDetailsScreenContent(movie = mockMovie, navController = mockNavController)
    }
}

@Preview(showBackground = true, name = "Details Light")
@Composable
fun MovieDetailsScreenLightPreview() {
    ViperMovaTheme(darkTheme = false) {
         // Criar NavController diretamente para o preview
        val mockNavController = NavController(LocalContext.current)
        // Mock de Filme com alguns dados
        val mockMovie = Movie(
            id = "1", 
            title = "Coringa", 
            backdrop_path = "", 
            vote_average = 8.2f,
            release_year = 2019,
            genres = listOf("Crime", "Drama", "Thriller"),
            overview = "Durante os anos 1980, um comediante de stand-up falido é levado à loucura e se torna uma figura psicopata de crime e caos em Gotham City, tornando-se uma figura infame.",
             movie_cast = listOf(
                CastMember(name = "Joaquin Phoenix", character = "Arthur Fleck", profile_path = ""),
                CastMember(name = "Robert De Niro", character = "Murray Franklin", profile_path = "")
            )
        )
        MovieDetailsScreenContent(movie = mockMovie, navController = mockNavController)
    }
}

// Função auxiliar para previews, contendo apenas o layout principal
@Composable
fun MovieDetailsScreenContent(movie: Movie, navController: NavController) {
     val scrollState = rememberScrollState()
     Column(
        modifier = Modifier
            .fillMaxSize()
             .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
    ) {
        MovieBackdrop(movie = movie, navController = navController)
        MoviePrimaryInfo(movie = movie)
        ActionButtons(
            onPlayClick = { /* TODO: Implementar lógica para iniciar o player */ }
        )
        MovieSynopsis(movie = movie)
        MovieCastSection(castList = movie.movie_cast ?: emptyList())
        TabSection()
    }
} 