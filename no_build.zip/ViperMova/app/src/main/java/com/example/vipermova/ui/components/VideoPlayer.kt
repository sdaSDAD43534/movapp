package com.example.vipermova.ui.components

import android.app.Activity
import android.content.pm.ActivityInfo
import android.util.Log
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.FrameLayout
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import com.example.vipermova.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.media3.common.C

private val Purple = Color(0xFF9C27B0)
private const val TAG = "VideoPlayer"

private object VideoPlayerState {
    var currentPosition: Long = 0
    var isPlaying: Boolean = false
}

@Composable
fun VideoPlayer(
    videoUrl: String,
    backdropUrl: String?,
    modifier: Modifier = Modifier,
    onBackClick: () -> Unit
) {
    Log.d(TAG, "Iniciando VideoPlayer com URL: $videoUrl")
    
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val activity = remember { context as? Activity }
    val lifecycleOwner = LocalLifecycleOwner.current

    var isPlaying by remember { mutableStateOf(VideoPlayerState.isPlaying) }
    var showControls by remember { mutableStateOf(false) }
    var isBuffering by remember { mutableStateOf(false) }
    var currentPosition by remember { mutableStateOf(VideoPlayerState.currentPosition) }
    var duration by remember { mutableStateOf(0L) }
    var isSeeking by remember { mutableStateOf(false) }
    var isFullscreen by remember { mutableStateOf(false) }
    var hasStartedPlaying by remember { mutableStateOf(false) }

    val playerModifier = if (isFullscreen) {
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    } else {
        modifier
            .fillMaxWidth()
            .aspectRatio(16f/9f)
            .background(Color.Black)
    }

    // Criar o ExoPlayer de forma estável
    val exoPlayer = remember(videoUrl) {
        Log.d(TAG, "Criando novo ExoPlayer para URL: $videoUrl")
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUrl))
            repeatMode = Player.REPEAT_MODE_OFF
            if (VideoPlayerState.currentPosition > 0) {
                Log.d(TAG, "Restaurando posição salva: ${VideoPlayerState.currentPosition}ms")
                seekTo(VideoPlayerState.currentPosition)
                if (VideoPlayerState.isPlaying) {
                    play()
                }
            }
            prepare()
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    Log.d(TAG, "Estado do player mudou para: ${getPlaybackStateString(playbackState)}")
                    isBuffering = playbackState == Player.STATE_BUFFERING
                    if (playbackState == Player.STATE_READY) {
                        duration = this@apply.duration
                        Log.d(TAG, "Duração total do vídeo: ${duration}ms")
                    }
                }

                override fun onIsPlayingChanged(playing: Boolean) {
                    Log.d(TAG, "IsPlaying mudou para: $playing")
                    isPlaying = playing
                    VideoPlayerState.isPlaying = playing
                    if (playing) {
                        currentPosition = this@apply.currentPosition
                        VideoPlayerState.currentPosition = currentPosition
                    }
                }

                override fun onPositionDiscontinuity(
                    oldPosition: Player.PositionInfo,
                    newPosition: Player.PositionInfo,
                    reason: Int
                ) {
                    Log.d(TAG, "Posição mudou de ${oldPosition.positionMs}ms para ${newPosition.positionMs}ms")
                    if (!isSeeking) {
                        currentPosition = newPosition.positionMs
                        VideoPlayerState.currentPosition = newPosition.positionMs
                    }
                }
            })
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
        }
    }

    SideEffect {
        activity?.let { act ->
            isFullscreen = act.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }

    // Função para alternar modo tela cheia
    val toggleFullscreen: () -> Unit = {
        activity?.let { act ->
            VideoPlayerState.currentPosition = exoPlayer.currentPosition
            
            val novaOrientacao = if (!isFullscreen) {
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            } else {
                ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
            isFullscreen = !isFullscreen
            act.requestedOrientation = novaOrientacao
            
            exoPlayer.videoScalingMode = if (isFullscreen) {
                C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            } else {
                C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            }

            // Dar play automaticamente quando entrar em tela cheia
            if (isFullscreen) {
                hasStartedPlaying = true
                isPlaying = true
                VideoPlayerState.isPlaying = true
                exoPlayer.playWhenReady = true
                exoPlayer.play()
                Log.d(TAG, "Iniciando reprodução automática em tela cheia")
            }
        }
        Unit
    }

    // Atualizar a posição atual periodicamente
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            if (!isSeeking) {
                currentPosition = exoPlayer.currentPosition
                VideoPlayerState.currentPosition = currentPosition
            }
            delay(200) // Atualiza a cada 200ms para uma experiência mais suave
        }
    }

    // Esconder controles automaticamente quando o vídeo começar a tocar
    LaunchedEffect(isPlaying, isBuffering) {
        if (isPlaying && !isBuffering && hasStartedPlaying) {
            delay(2000) // Espera 2 segundos após começar a tocar
            showControls = false
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            Log.d(TAG, "Evento do ciclo de vida: $event")
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    Log.d(TAG, "ON_PAUSE - Pausando player na posição: ${exoPlayer.currentPosition}ms")
                    exoPlayer.pause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    Log.d(TAG, "ON_RESUME - Player está na posição: ${exoPlayer.currentPosition}ms")
                }
                Lifecycle.Event.ON_DESTROY -> {
                    Log.d(TAG, "ON_DESTROY - Liberando player")
                    exoPlayer.release()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            Log.d(TAG, "Removendo observer do ciclo de vida")
            lifecycleOwner.lifecycle.removeObserver(observer)
            exoPlayer.release()
        }
    }

    Box(
        modifier = playerModifier
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { _ ->
                        showControls = !showControls
                        Unit
                    }
                )
            }
    ) {
        // Player (sempre presente, mas inicialmente invisível)
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .alpha(if (hasStartedPlaying) 1f else 0f)
        )

        // Backdrop (mostrar apenas se o vídeo nunca foi iniciado)
        if (!hasStartedPlaying && backdropUrl != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = backdropUrl,
                    contentDescription = null,
                    contentScale = ContentScale.FillHeight,
                    modifier = Modifier.fillMaxSize()
                )
                // Overlay escuro sobre o backdrop
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                )
            }
        }

        // Overlay escuro para os controles
        if (showControls) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.2f))
            )
        }

        // Botão de voltar (sempre visível, ajustado para tela cheia)
        IconButton(
            onClick = {
                if (isFullscreen) {
                    toggleFullscreen()
                } else {
                    onBackClick()
                }
            },
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(top = 8.dp, start = 16.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Voltar",
                tint = Color.White
            )
        }

        // Botão de play central (mostrar quando o vídeo não começou OU quando os controles estiverem visíveis)
        if (!hasStartedPlaying || (hasStartedPlaying && showControls)) {
            IconButton(
                onClick = {
                    if (!hasStartedPlaying) {
                        hasStartedPlaying = true
                        showControls = true
                        exoPlayer.play()
                    } else {
                        if (isPlaying) {
                            exoPlayer.pause()
                        } else {
                            exoPlayer.play()
                        }
                    }
                },
                modifier = Modifier
                    .size(72.dp)
                    .align(Alignment.Center)
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pausar" else "Reproduzir",
                    tint = Purple,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        // Loading indicator (mostrar durante o buffering e após começar)
        if (isBuffering && hasStartedPlaying) {
            CircularProgressIndicator(
                modifier = Modifier.align(Alignment.Center),
                color = Color.White
            )
        }

        // Barra de progresso e tempo (mostrar apenas com controles visíveis e após o primeiro play)
        if (showControls && hasStartedPlaying) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.2f))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Tempo atual
                Text(
                    text = if (duration > 0) formatTime(currentPosition) else "00:00",
                    color = Color.White,
                    style = MaterialTheme.typography.bodySmall
                )

                // Barra de progresso
                Slider(
                    value = if (duration > 0) (currentPosition.toFloat() / duration.toFloat()) else 0f,
                    onValueChange = { newValue ->
                        isSeeking = true
                        currentPosition = (newValue * duration).toLong()
                    },
                    onValueChangeFinished = {
                        if (isSeeking) {
                            Log.d(TAG, "Seeking para posição: ${currentPosition}ms")
                            exoPlayer.seekTo(currentPosition)
                            VideoPlayerState.currentPosition = currentPosition
                            isSeeking = false
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = Purple,
                        activeTrackColor = Color.White,
                        inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                    )
                )

                // Tempo total
                Text(
                    text = if (duration > 0) formatTime(duration) else "00:00",
                    color = Color.White,
                    style = MaterialTheme.typography.bodySmall
                )

                // Botão de tela cheia atualizado
                IconButton(
                    onClick = toggleFullscreen,
                    modifier = Modifier.size(48.dp)
                ) {
                    Icon(
                        imageVector = if (isFullscreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                        contentDescription = if (isFullscreen) "Sair da tela cheia" else "Tela cheia",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

private fun formatTime(milliseconds: Long): String {
    if (milliseconds <= 0) return "00:00"
    
    val totalSeconds = milliseconds / 1000
    val hours = (totalSeconds / 3600).toInt()
    val minutes = ((totalSeconds % 3600) / 60).toInt()
    val seconds = (totalSeconds % 60).toInt()
    
    return if (hours > 0) {
        // Formato HH:MM:SS para vídeos com mais de uma hora
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        // Formato MM:SS para vídeos com menos de uma hora
        String.format("%02d:%02d", minutes, seconds)
    }
}

private fun getPlaybackStateString(state: Int): String = when (state) {
    Player.STATE_IDLE -> "IDLE"
    Player.STATE_BUFFERING -> "BUFFERING"
    Player.STATE_READY -> "READY"
    Player.STATE_ENDED -> "ENDED"
    else -> "UNKNOWN"
}