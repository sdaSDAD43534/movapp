package com.example.vipermova.ui.checkout

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.vipermova.model.PaymentMethod
import com.example.vipermova.model.SubscriptionPlan
import com.example.vipermova.ui.subscription.mockPlans // Importar planos mockados
import com.example.vipermova.ui.theme.ViperMovaTheme
import java.text.NumberFormat
import java.util.*
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DevicesOther
import androidx.compose.material.icons.filled.Event // Para duração
import androidx.compose.material3.HorizontalDivider // Para o divisor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    planId: String?,
    navController: NavController
) {
    // Encontrar o plano selecionado (usando mock data por enquanto)
    val selectedPlan = remember(planId) { mockPlans.find { it.id == planId } }
    var selectedPaymentMethod by remember { mutableStateOf<PaymentMethod?>(null) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Finalizar Compra", fontWeight = FontWeight.SemiBold) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    navigationIconContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
    ) { paddingValues ->
        if (selectedPlan == null) {
            // Exibir erro se o plano não for encontrado
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                 Column(horizontalAlignment = Alignment.CenterHorizontally) {
                     Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                     Spacer(modifier = Modifier.height(8.dp))
                     Text("Plano não encontrado!", color = MaterialTheme.colorScheme.error)
                 }
            }
            return@Scaffold // Sair da composição do Scaffold
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues) // Aplicar padding do Scaffold (menos o bottomBar)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 16.dp /*, bottom = 80.dp*/),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Resumo do Pedido",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Card com Resumo do Plano
            PlanSummaryCard(plan = selectedPlan)

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Selecione o Método de Pagamento",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Start)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Seleção de Método de Pagamento (agora clicável)
            CheckoutPaymentMethodSelector(
                selectedMethod = selectedPaymentMethod,
                onMethodSelected = { selectedPaymentMethod = it }
            )

            Spacer(modifier = Modifier.height(24.dp)) // Espaço antes do botão

            // Adicionar o botão aqui no final da Column
            Button(
                onClick = { /* TODO: Processar Pagamento */ },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp) // Padding inferior para o botão
                    .height(50.dp),
                enabled = selectedPaymentMethod != null, // Habilitar só se método selecionado
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Confirmar Pagamento", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            // Não precisa mais do formulário aqui
            // Espaço adicional no final será coberto pelo padding da Column
        }
    }
}

@Composable
fun PlanSummaryCard(plan: SubscriptionPlan) {
     val currencyFormat = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp), // Aumentar o arredondamento
        // Remover a borda, a imagem não tem
        // border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha=0.1f) // Fundo sutil
        )
    ) {
        // Usar Column como layout principal
        Column(modifier = Modifier.padding(16.dp)) {
            // 1. Header: Ícone e Título
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (plan.icon != null) {
                    Icon(
                        imageVector = plan.icon, // Usar ícone do plano
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp) // Ícone menor como na imagem
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = "Vip ${plan.title}", // Adicionar "Vip" como na imagem
                    style = MaterialTheme.typography.titleMedium, // Manter tamanho
                    fontWeight = FontWeight.Bold // Negrito
                )
                // TODO: Adicionar badge "MAIS VENDIDO!" se necessário
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 2. Preço e Duração
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom // Alinhar pela base como na imagem
            ) {
                // Coluna para Preço
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Valor do Plano",
                        style = MaterialTheme.typography.labelSmall, // Texto menor para label
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        buildAnnotatedString {
                            val formattedPrice = currencyFormat.format(plan.price)
                            val mainPart = formattedPrice.substringBefore(',') // R$ 9
                            val centsPart = formattedPrice.substringAfter(',', "") // ,90

                            append("R$") // Adicionar R$ manualmente
                            withStyle(style = SpanStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)) {
                                append(mainPart)
                                if (centsPart.isNotEmpty()) {
                                    append(",")
                                    append(centsPart)
                                }
                            }
                            withStyle(style = SpanStyle(fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)) {
                                append(" ") // Espaço antes do período
                                append(plan.period)
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Dispositivos e Benefícios (Contagem)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Bottom
            ) {
                // Coluna para Dispositivos
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Dispositivos",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.DevicesOther, // Ícone de dispositivos
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                             modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "1 dispositivo", // Valor mockado
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Divisor
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 8.dp),
                thickness = 1.dp,
                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
            )

            // 5. Lista de Benefícios Detalhada
            Column(modifier = Modifier.padding(top = 8.dp)) {
                plan.benefits.forEach { benefit ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp) // Espaçamento entre itens da lista
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check, // Ícone de check
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = benefit,
                            style = MaterialTheme.typography.bodyMedium, // Fonte normal para lista
                            color = MaterialTheme.colorScheme.onSurfaceVariant // Cor mais suave
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CheckoutPaymentMethodSelector(
    selectedMethod: PaymentMethod?,
    onMethodSelected: (PaymentMethod) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp) // Espaçamento entre cards
    ) {
        PaymentMethod.entries.forEach { method ->
            // Usar weight para dividir o espaço
            CheckoutPaymentMethodCard(
                method = method,
                isSelected = selectedMethod == method,
                onClick = { onMethodSelected(method) },
                 modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun CheckoutPaymentMethodCard(
    method: PaymentMethod,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
    val containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha=0.3f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)

    Card(
        modifier = modifier
            .height(80.dp) // Manter altura original
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, borderColor),
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = method.icon,
                contentDescription = method.title,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = method.title,
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
                 color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// --- Preview ---
@Preview(showBackground = true, name = "Checkout Dark")
@Composable
fun CheckoutScreenDarkPreview() {
    ViperMovaTheme(darkTheme = true) {
        CheckoutScreen(planId = mockPlans.first().id, navController = rememberNavController())
    }
}

@Preview(showBackground = true, name = "Checkout Light")
@Composable
fun CheckoutScreenLightPreview() {
    ViperMovaTheme(darkTheme = false) {
         CheckoutScreen(planId = mockPlans.first().id, navController = rememberNavController())
    }
}

@Preview(showBackground = true, name = "Checkout Invalid Plan")
@Composable
fun CheckoutScreenInvalidPreview() {
    ViperMovaTheme(darkTheme = true) {
         CheckoutScreen(planId = "invalid_id", navController = rememberNavController())
    }
} 