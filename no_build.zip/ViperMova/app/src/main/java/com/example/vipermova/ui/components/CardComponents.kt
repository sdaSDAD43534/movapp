package com.example.vipermova.ui.components

import androidx.compose.ui.unit.Dp

data class CardDimensions(
    val width: Dp,
    val height: Dp
)

data class ImageSize(
    val width: Int,
    val height: Int
) 