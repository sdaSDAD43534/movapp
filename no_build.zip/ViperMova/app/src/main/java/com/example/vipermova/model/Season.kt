package com.example.vipermova.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName

@Serializable
data class Season(
    val id: String, // UUID
    val series_id: String? = null, // UUID
    val season_number: Int,
    val title: String? = null,
    val overview: String? = null,
    val poster_url: String? = null, // Corrigido de poster_url
    val episode_count: Int? = null
    // Adicione outros campos conforme necessário (ex: air_date)
) 