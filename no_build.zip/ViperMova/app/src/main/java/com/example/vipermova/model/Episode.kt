package com.example.vipermova.model

import kotlinx.serialization.Serializable

@Serializable
data class Episode(
    val id: String, // UUID
    val series_id: String? = null, // UUID
    val season_id: String? = null, // UUID
    val episode_number: Int,
    val title: String? = null,
    val overview: String? = null,
    val still_path: String? = null, // Imagem do episódio
    val duration: Int? = null,
    val imdb_id: String? = null
    // Adicione outros campos conforme necessário (ex: air_date)
) 