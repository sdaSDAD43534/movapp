package com.example.vipermova.ui.explore

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.vipermova.model.Movie
import com.example.vipermova.model.Series
import com.example.vipermova.MovieCard
import com.example.vipermova.SeriesCard
import com.example.vipermova.LocalNavController
import com.example.vipermova.ui.theme.ViperMovaTheme
import com.example.vipermova.ui.components.CardDimensions

@Composable
fun ExploreScreen(bottomPadding: Dp = 0.dp) {
    val configuration = LocalConfiguration.current
    val dimensions = remember(configuration) {
        val screenWidth = configuration.screenWidthDp.dp
        val screenHeight = configuration.screenHeightDp.dp
        CardDimensions(
            width = screenWidth / 3.2f,
            height = screenHeight / 4.0f
        )
    }

    // Dados de exemplo para teste
    val movies = remember { List(5) { Movie(id = "m$it", title = "Filme $it", coverUrl = "") } }
    val series = remember { List(5) { Series(id = "s$it", title = "Série $it", coverUrl = "") } }
    val combinedList = remember { movies + series }

    // Obter o NavController
    val navController = LocalNavController.current

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding() // Adiciona padding para a barra de status
                .padding(bottom = bottomPadding) // Mantém padding para a barra de navegação
        ) {
            // Barra Superior com Pesquisa e Filtro
            SearchBarWithFilter(searchQuery = "", onQueryChange = { /* TODO: Implementar mudança de query */ })

            // Grade de Conteúdo
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(combinedList, key = { if (it is Movie) "m-${it.id}" else "s-${(it as Series).id}" }) { item ->
                    when (item) {
                        is Movie -> MovieCard(
                            movie = item,
                            dimensions = dimensions,
                            onClick = { navController?.navigate("movieDetails/${item.id}") }
                        )
                        is Series -> SeriesCard(
                            series = item,
                            dimensions = dimensions,
                            onClick = { navController?.navigate("seriesDetails/${item.id}") }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SearchBarWithFilter(
    searchQuery: String,
    onQueryChange: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onQueryChange,
            modifier = Modifier
                .weight(1f)
                .height(50.dp) // Altura padrão para TextFields
                .clip(RoundedCornerShape(12.dp)), // Bordas arredondadas
            placeholder = { Text("Pesquisar", style = MaterialTheme.typography.bodyMedium) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Ícone de Pesquisa", tint = MaterialTheme.colorScheme.onSurfaceVariant) },
            singleLine = true,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                focusedIndicatorColor = Color.Transparent, // Sem linha indicadora
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = MaterialTheme.colorScheme.primary,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
            ),
            textStyle = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.width(8.dp))

        // Botão de Filtro
        IconButton(
            onClick = { /* TODO: Ação do Filtro */ },
            modifier = Modifier
                .size(50.dp) // Tamanho consistente com a barra
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = "Filtrar",
                tint = MaterialTheme.colorScheme.primary // Cor primária para o ícone
            )
        }
    }
}

// Previews
@Preview(showBackground = true, name = "Explore Dark")
@Composable
fun ExploreScreenPreview() {
    ViperMovaTheme(darkTheme = true) {
        ExploreScreen(bottomPadding = 0.dp) // Sem padding no preview isolado
    }
}

@Preview(showBackground = true, name = "Explore Light")
@Composable
fun ExploreScreenLightPreview() {
    ViperMovaTheme(darkTheme = false) {
        ExploreScreen(bottomPadding = 0.dp) // Sem padding no preview isolado
    }
} 