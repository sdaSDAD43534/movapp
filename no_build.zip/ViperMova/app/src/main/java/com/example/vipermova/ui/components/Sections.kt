package com.example.vipermova.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
// Importar NavController não é mais necessário aqui
// import androidx.navigation.NavController
import com.example.vipermova.model.Movie
import com.example.vipermova.model.Series
// Importar Cards de MainActivity ou de onde estiverem definidos
import com.example.vipermova.MovieCard
import com.example.vipermova.SeriesCard
// Imports para dimensões
import com.example.vipermova.ui.components.CardDimensions

@Composable
fun SimpleMovieSection(
    title: String,
    movies: List<Movie>,
    // Receber lambda de clique em vez de NavController
    onMovieClick: (String) -> Unit
) {
    val configuration = LocalConfiguration.current
    val dimensions = remember(configuration) {
        val screenWidth = configuration.screenWidthDp.dp
        val screenHeight = configuration.screenHeightDp.dp
        // Usar as dimensões corretas que definimos antes
        CardDimensions(
            width = screenWidth / 3.2f, 
            height = screenHeight / 4.0f
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp) // Padding ajustado
    ) {
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 12.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(movies, key = { it.id ?: "" }) { movie ->
                MovieCard(
                    movie = movie,
                    dimensions = dimensions,
                    // Passar a lambda de clique correta
                    onClick = { movie.id?.let { id -> onMovieClick(id) } }
                )
            }
        }
    }
}

@Composable
fun SimpleSeriesSection(
    title: String,
    seriesList: List<Series>,
    // Receber lambda de clique em vez de NavController
    onSeriesClick: (String) -> Unit
) {
    val configuration = LocalConfiguration.current
    val dimensions = remember(configuration) {
        val screenWidth = configuration.screenWidthDp.dp
        val screenHeight = configuration.screenHeightDp.dp
        CardDimensions(
            width = screenWidth / 3.2f,
            height = screenHeight / 4.0f
        )
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp)
    ) {
        Text(
            text = title,
            color = MaterialTheme.colorScheme.onBackground,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, bottom = 12.dp)
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(seriesList, key = { it.id ?: "" }) { series ->
                SeriesCard(
                    series = series,
                    dimensions = dimensions,
                    // Passar a lambda de clique correta
                    onClick = { series.id?.let { id -> onSeriesClick(id) } }
                )
            }
        }
    }
} 