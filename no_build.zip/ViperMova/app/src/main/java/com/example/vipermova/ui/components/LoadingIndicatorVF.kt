package com.example.vipermova.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vipermova.ui.theme.ViperMovaTheme
import kotlinx.coroutines.delay

// Renomeado internamente e com novo design
@Composable
fun LoadingIndicatorViperFlix(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "ViperFlix", // Novo texto
                color = MaterialTheme.colorScheme.primary,
                fontSize = 48.sp, // Tamanho ajustado para o nome
                fontWeight = FontWeight.Bold // Pode ajustar o peso da fonte
            )
            Spacer(modifier = Modifier.height(48.dp)) // Espaço maior
            PulsingDotsIndicator() // Indicador com pontos pulsantes
        }
    }
}

@Composable
fun PulsingDotsIndicator(
    dotCount: Int = 3,
    dotSize: Dp = 12.dp,
    dotColor: Color = MaterialTheme.colorScheme.primary,
    spacing: Dp = 10.dp,
    animationDuration: Int = 400 // Duração para cada pulso
) {
    val infiniteTransition = rememberInfiniteTransition(label = "dots")
    val scales = List(dotCount) { index ->
        infiniteTransition.animateFloat(
            initialValue = 0.5f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = keyframes {
                    durationMillis = animationDuration * dotCount
                    0.5f at (animationDuration * index) // Começa pequeno na sua vez
                    1.0f at (animationDuration * index + animationDuration / 2) // Aumenta
                    0.5f at (animationDuration * index + animationDuration) // Diminui
                    0.5f at (animationDuration * dotCount) // Mantém pequeno até o ciclo recomeçar
                },
                repeatMode = RepeatMode.Restart
            ),
            label = "scale_$index"
        )
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(spacing)
    ) {
        scales.forEach { scale ->
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .graphicsLayer {
                        scaleX = scale.value
                        scaleY = scale.value
                    }
                    .clip(CircleShape)
                    .background(dotColor)
            )
        }
    }
}

// Atualizar previews para usar o novo nome interno
@Preview(showBackground = true, name = "Loading ViperFlix Dark")
@Composable
fun LoadingIndicatorViperFlixPreviewDark() {
    ViperMovaTheme(darkTheme = true) {
        LoadingIndicatorViperFlix()
    }
}

@Preview(showBackground = true, name = "Loading ViperFlix Light")
@Composable
fun LoadingIndicatorViperFlixPreviewLight() {
    ViperMovaTheme(darkTheme = false) {
        LoadingIndicatorViperFlix()
    }
} 