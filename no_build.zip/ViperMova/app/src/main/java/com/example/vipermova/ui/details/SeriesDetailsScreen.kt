package com.example.vipermova.ui.details

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.vipermova.model.Series
import com.example.vipermova.ui.components.CardDimensions
import com.example.vipermova.ui.components.LoadingIndicatorViperFlix
import androidx.compose.ui.platform.LocalConfiguration

@Composable
fun SeriesDetailsScreen(
    seriesId: String?,
    navController: NavController
) {
    var currentSeries by remember { mutableStateOf<Series?>(null) }
    var isLoading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    
    val configuration = LocalConfiguration.current
    val dimensions = remember(configuration) {
        val screenWidth = configuration.screenWidthDp.dp
        val screenHeight = configuration.screenHeightDp.dp
        CardDimensions(
            width = screenWidth / 3.2f,
            height = screenHeight / 4.0f
        )
    }

    LaunchedEffect(seriesId) {
        try {
            isLoading = true
            error = null
            
            // TODO: Implementar busca real dos dados da série usando Supabase
            // Simular carregamento da série por enquanto
            kotlinx.coroutines.delay(1500) // Simular delay da rede
            currentSeries = Series(
                id = seriesId ?: "",
                title = "Série de Exemplo ID: $seriesId",
                coverUrl = ""
                // Adicionar outros campos se necessário
            )
            if (seriesId == null) { // Simular erro se ID for nulo
                 error = "ID da série inválido"
                 currentSeries = null
            }

        } catch (e: Exception) {
            error = e.message
            Log.e("SeriesDetails", "Erro ao carregar série: ${e.message}", e)
        } finally {
            isLoading = false
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        when {
            isLoading -> {
                LoadingIndicatorViperFlix()
            }
            error != null -> {
                Text(
                    text = error ?: "Erro desconhecido",
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(16.dp)
            )
            }
            currentSeries != null -> {
    Column(
        modifier = Modifier
            .fillMaxSize()
                        .padding(16.dp)
                ) {
                    Text(
                        text = currentSeries?.title ?: "",
                        style = MaterialTheme.typography.headlineMedium
                    )
        Spacer(modifier = Modifier.height(16.dp))
                    Text("Conteúdo detalhado da série aqui...")
                    // Adicionar outros componentes: backdrop, informações, temporadas, episódios, etc.
                }
            }
            else -> {
                 Text(
                    text = "Não foi possível carregar a série.",
                    modifier = Modifier.padding(16.dp)
                )
            }
        }
    }
} 