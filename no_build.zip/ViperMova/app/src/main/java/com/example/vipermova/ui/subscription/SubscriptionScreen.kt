package com.example.vipermova.ui.subscription

// Forçando atualização para corrigir formatação
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.vipermova.model.PaymentMethod
import com.example.vipermova.model.SubscriptionPlan
import com.example.vipermova.ui.theme.ViperMovaTheme
import java.text.NumberFormat
import java.util.* // Para formatação de moeda
import com.example.vipermova.LocalNavController // Importar se não estiver

// --- Dados Mockados (Substituir por dados reais/API) ---
val mockPlans = listOf(
    SubscriptionPlan(
        id = "monthly",
        title = "Mensal",
        price = 19.90,
        period = "/ mês",
        benefits = listOf(
            "Filmes e Séries Premium",
            "Assista sem anúncios",
            "Streaming em 4K disponível",
            "Suporte 24/7",
            "Download para assistir offline"
        ),
        icon = Icons.Default.WorkspacePremium // Ícone de exemplo
    ),
    SubscriptionPlan(
        id = "quarterly",
        title = "Trimestral",
        price = 49.90,
        period = "/ 3 meses",
        benefits = listOf(
             "Filmes e Séries Premium",
            "Assista sem anúncios",
            "Streaming em 4K disponível",
            "Suporte 24/7",
            "Download para assistir offline"
        ),
        icon = Icons.Default.Diamond // Ícone de exemplo
    ),
    SubscriptionPlan(
        id = "semi_annually",
        title = "Semestral",
        price = 89.90,
        period = "/ 6 meses",
        benefits = listOf(
             "Filmes e Séries Premium",
            "Assista sem anúncios",
            "Streaming em 4K disponível",
            "Suporte 24/7",
            "Download para assistir offline"
        ),
        icon = Icons.Default.Shield // Ícone de exemplo
    )
)

// --- Tela Principal ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscriptionScreen(navController: NavController) {
    // Remover Scaffold e TopAppBar. Usar Surface/Column diretamente.
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) { 
        Column(
            modifier = Modifier
                .fillMaxSize()
                // Adicionar padding para a barra de status manualmente
                .statusBarsPadding()
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Adicionar Botão Voltar no topo
            Box(modifier = Modifier.fillMaxWidth()) { // Box para alinhar botão à esquerda
                IconButton(
                    onClick = { navController.popBackStack() }, 
                    modifier = Modifier.align(Alignment.CenterStart)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                }
            }
            
            // Spacer(modifier = Modifier.height(24.dp)) // Remover ou ajustar spacer

            // Mover Título para cá
            Text(
                text = "Selecione um Plano",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                 modifier = Modifier.padding(bottom = 8.dp) // Adicionar padding abaixo do título
            )
            
            // Remover o Text "Selecione um Plano" que estava mais abaixo
            
            Text(
                text = "Aproveite vídeos em Full-HD, sem restrições, sem anúncios e faça downloads!",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Pager Horizontal para Planos
            SubscriptionPlanPager(plans = mockPlans)

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Métodos de Pagamento Aceitos",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Métodos de Pagamento (informativo)
            PaymentMethodInfo()
            
             Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

// --- Componentes da Tela ---

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SubscriptionPlanPager(plans: List<SubscriptionPlan>) {
    val pagerState = rememberPagerState(pageCount = { plans.size })
    val navController = LocalNavController.current // Obter navController aqui

    HorizontalPager(
        state = pagerState,
        contentPadding = PaddingValues(horizontal = 40.dp),
        pageSpacing = 16.dp
    ) { pageIndex ->
        // Passar navController para PlanCard
        PlanCard(plan = plans[pageIndex], navController = navController)
    }
}

@Composable
fun PlanCard(plan: SubscriptionPlan, navController: NavController?) {
    val currencyFormat = remember { NumberFormat.getCurrencyInstance(Locale("pt", "BR")) }

    Card(
        modifier = Modifier
            .fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        )
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 16.dp, horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (plan.icon != null) {
                 Icon(
                    imageVector = plan.icon,
                    contentDescription = plan.title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
            Text(
                text = plan.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Spacer(modifier = Modifier.height(4.dp))
             Text(buildAnnotatedString {
                withStyle(style = SpanStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)) {
                    val formattedPrice = currencyFormat.format(plan.price)
                    val parts = formattedPrice.split(',')
                    append(parts.getOrElse(0) { formattedPrice })
                    if (parts.size > 1) {
                         append(",")
                         append(parts[1])
                    }
                }
                 withStyle(style = SpanStyle(fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)) {
                    append(" ")
                    append(plan.period)
                }
            })

            Spacer(modifier = Modifier.height(16.dp))

            // Benefícios em Grid 2x2
            val benefitsToShow = plan.benefits.take(4)
            if (benefitsToShow.isNotEmpty()) {
                Column(modifier = Modifier.fillMaxWidth()) { // Column para empilhar as linhas
                    // Primeira Linha de Benefícios
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween // Espaçar itens na linha
                    ) {
                        if (benefitsToShow.size >= 1) {
                            BenefitItem(text = benefitsToShow[0], modifier = Modifier.weight(1f)) // Usar weight para dividir espaço
                        }
                        if (benefitsToShow.size >= 2) {
                             BenefitItem(text = benefitsToShow[1], modifier = Modifier.weight(1f))
                        }
                    }
                    // Segunda Linha de Benefícios
                     if (benefitsToShow.size > 2) { // Só mostrar segunda linha se houver mais de 2 benefícios
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                             if (benefitsToShow.size >= 3) {
                                BenefitItem(text = benefitsToShow[2], modifier = Modifier.weight(1f))
                            }
                             if (benefitsToShow.size >= 4) {
                                BenefitItem(text = benefitsToShow[3], modifier = Modifier.weight(1f))
                            } else {
                                Spacer(modifier = Modifier.weight(1f)) // Ocupar espaço se não houver 4º benefício
                            }
                        }
                     } // Fim da condição da segunda linha
                }
            } else {
                Spacer(modifier = Modifier.height(36.dp)) // Altura mínima se não houver benefícios
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = { 
                     // Usar o navController recebido
                    navController?.navigate("checkout/${plan.id}")
                },
                modifier = Modifier.fillMaxWidth().height(44.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Comprar Agora", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

// Recriar BenefitItem com texto e ícone
@Composable
fun BenefitItem(text: String, modifier: Modifier = Modifier) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.padding(vertical = 4.dp) // Padding vertical menor
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(16.dp) // Ícone ainda menor para o grid
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall, // Fonte menor para caber
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// Novo Composable para informação de pagamento
@Composable
fun PaymentMethodInfo() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly // Espaçamento uniforme
    ) {
        PaymentMethod.entries.forEach { method ->
            // Usar um novo Card informativo sem clique
            PaymentMethodInfoCard(method = method)
        }
    }
}

// Card informativo (sem clique, sem estado de seleção)
@Composable
fun PaymentMethodInfoCard(method: PaymentMethod) {
     Card(
        modifier = Modifier
            .size(width = 100.dp, height = 80.dp), // Tamanho fixo
        shape = RoundedCornerShape(12.dp),
         // Remover borda e container de seleção
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = method.icon,
                contentDescription = method.title,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = method.title,
                style = MaterialTheme.typography.labelSmall,
                textAlign = TextAlign.Center,
                 color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// --- Preview ---
@Preview(showBackground = true, name = "Subscription Dark")
@Composable
fun SubscriptionScreenDarkPreview() {
    ViperMovaTheme(darkTheme = true) {
        SubscriptionScreen(rememberNavController())
    }
}

@Preview(showBackground = true, name = "Subscription Light")
@Composable
fun SubscriptionScreenLightPreview() {
    ViperMovaTheme(darkTheme = false) {
        SubscriptionScreen(rememberNavController())
    }
} 