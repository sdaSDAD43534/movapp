import java.util.Properties
import java.io.FileInputStream

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.kotlin.compose.compiler)
}

// Função para ler propriedades do local.properties
fun getLocalProperty(key: String, file: File): String {
    val properties = Properties()
    properties.load(FileInputStream(file))
    return properties.getProperty(key) ?: ""
}

android {
    namespace = "com.example.vipermova"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.vipermova"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Ler credenciais do local.properties
        val localPropertiesFile = rootProject.file("local.properties")
        if (localPropertiesFile.exists()) {
            val supabaseUrlValue = getLocalProperty("supabaseUrl", localPropertiesFile)
            val supabaseKeyValue = getLocalProperty("supabaseKey", localPropertiesFile)
            buildConfigField("String", "SUPABASE_URL", "\"${supabaseUrlValue}\"")
            buildConfigField("String", "SUPABASE_KEY", "\"${supabaseKeyValue}\"")
        } else {
            // Lançar erro se local.properties não for encontrado ou as chaves estiverem faltando
            // (ou defina valores padrão, mas não recomendado para credenciais)
            throw GradleException("local.properties not found or Supabase keys missing.")
        }

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            // Você pode querer definir as credenciais de release aqui também,
            // possivelmente de variáveis de ambiente no seu CI/CD
        }
        debug {
             // As credenciais já estão no defaultConfig, então geralmente não precisa repetir aqui
             // a menos que tenha configurações específicas para debug.
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    kotlinOptions {
        jvmTarget = "11"
    }
    buildFeatures {
        buildConfig = true
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {

    // Supabase
    implementation(platform(libs.supabase.bom))
    implementation(libs.supabase.gotrue)
    implementation(libs.supabase.postgrest)
    // implementation(libs.supabase.storage)
    // implementation(libs.supabase.realtime)

    // Ktor (necessário pelo Supabase)
    implementation(libs.ktor.client.cio)
    // Outras dependências Ktor já são transitivas do Supabase, mas pode adicionar explicitamente se necessário

    // Gson para processamento JSON
    implementation("com.google.code.gson:gson:2.10.1")

    // Core Android & Material
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)

    // Jetpack Compose
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.material.icons.core)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.androidx.compose.foundation)
    debugImplementation(libs.androidx.compose.ui.tooling)

    // Coil (Image Loading)
    implementation(libs.coil.compose)

    // Media3 (ExoPlayer)
    implementation("androidx.media3:media3-exoplayer:1.2.1")
    implementation("androidx.media3:media3-ui:1.2.1")
    implementation("androidx.media3:media3-common:1.2.1")

    // Teste
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
}